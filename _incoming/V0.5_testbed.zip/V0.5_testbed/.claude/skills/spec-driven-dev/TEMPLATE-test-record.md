# テスト記録の記載形式(`docs/test-records/YYYYMMDD-HHMM-test-record.md`)

このテンプレートは、`docs/P008-test-direction/T000-{test-name}.md`(結合テスト)・`docs/P009-acceptance-direction/A000-{test-name}.md`(受け入れ結合テスト)のいずれについても共通の記録形式である。P103(結合テスト実行)・P201(実装横断レビュー、P009実行分)・P205(結合テスト再実施)は、いずれもこの形式に従って `docs/test-records/YYYYMMDD-HHMM-test-record.md` に記録を残す。

* 1つのテストタスク(T0NNまたはA0NN)につき、1つの見出しブロックを作成する。
* 同じ実行日時にまとめて複数のテストを実行した場合は、同一ファイルに複数のブロックを追記してよい。
* 再実行(P205など)の場合は、新しいファイル(新しい `YYYYMMDD-HHMM`)を追加するか、既存ファイルに追記する。過去の記録を上書き・削除しない(再実行の経緯を追跡できるようにするため)。
* テストIDの接頭辞(`T` または `A`)は、対応する `docs/P008-test-direction/` または `docs/P009-acceptance-direction/` のファイル名・目次のIDと一致させる。

## 記載形式

```markdown
## {T0NN または A0NN}: テスト名

- 実行日時:
- 実行者:
- 対象ブランチ/コミット:
- 参照したテスト指示: docs/P008-test-direction/T0NN-{test-name}.md (またはdocs/P009-acceptance-direction/A0NN-{test-name}.md)
- 実行環境:
- 事前ビルド結果:
- 実行コマンド:
- 結果: PASS / FAIL / BLOCKED / NOT RUN
- 期待結果:
- 実際の結果:
- 失敗ログ抜粋:
- 再現手順:
- 影響がありそうなモジュール:
- 次工程への申し送り:
```

## 各項目の記載ルール

* 「結果」は必ず `PASS` / `FAIL` / `BLOCKED` / `NOT RUN` のいずれか1つを記載する。
* `FAIL` / `BLOCKED` の場合、「失敗ログ抜粋」「再現手順」「影響がありそうなモジュール」は空欄にせず、可能な範囲で具体的に記載する(空欄が許されるのは、そもそも実行できず情報が得られなかった `NOT RUN` の場合のみ)。
* 「参照したテスト指示」には、対応する `T0NN-*.md` または `A0NN-*.md` への相対パスを必ず記載し、テスト記録とテスト指示の対応関係を追跡できるようにする。
* このファイルはテスト結果の一次記録である。修正計画(P202)・修正内容の詳細(`docs/P202-fix-plan/fixed/F000-*.md`)・解決済み/未解決一覧(`TEMPLATE-P202-fix-resolved.md`/`TEMPLATE-P202-fix-unresolved.md`)からは、この記録を参照する形で相互にリンクする。
