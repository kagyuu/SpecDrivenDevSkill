import unittest

from tests.integration.helpers import LiveServer, session_cookie


class TestU004UsersAndAuthz(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def _login(self, employee_id, password):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": employee_id, "password": password}
        )
        self.assertEqual(status, 200, body)
        return session_cookie(set_cookie)

    def test_admin_creates_user_general_forbidden_from_admin_apis(self):
        admin_cookie = self._login("admin", "admin12345")
        status, created, _ = self.server.request(
            "POST",
            "/api/users",
            {"employee_id": "u900", "name": "結合テスト太郎", "role": "general", "password": "testpass123"},
            cookie=admin_cookie,
        )
        self.assertEqual(status, 201, created)

        general_cookie = self._login("u001", "password01")
        status, forbidden, _ = self.server.request("GET", "/api/users", cookie=general_cookie)
        self.assertEqual(status, 403, forbidden)

        status, forbidden2, _ = self.server.request(
            "POST", "/api/rooms", {"name": "権限テスト", "capacity": 2, "equipment": ""}, cookie=general_cookie
        )
        self.assertEqual(status, 403, forbidden2)

        status, forbidden3, _ = self.server.request(
            "DELETE", f"/api/users/{created['id']}", cookie=general_cookie
        )
        self.assertEqual(status, 403, forbidden3)

        # admin は問題なく削除(論理削除)できる
        status, _, _ = self.server.request("DELETE", f"/api/users/{created['id']}", cookie=admin_cookie)
        self.assertEqual(status, 204)


if __name__ == "__main__":
    unittest.main()
