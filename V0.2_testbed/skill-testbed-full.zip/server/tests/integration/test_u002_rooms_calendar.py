import unittest
from datetime import date, timedelta

from tests.integration.helpers import LiveServer, session_cookie


class TestU002RoomsCalendar(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def _login(self, employee_id, password):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": employee_id, "password": password}
        )
        self.assertEqual(status, 200, body)
        return session_cookie(set_cookie)

    def test_admin_creates_room_general_sees_it_and_reservations_read_apis_work(self):
        admin_cookie = self._login("admin", "admin12345")
        status, room, _ = self.server.request(
            "POST", "/api/rooms", {"name": "結合テスト会議室", "capacity": 3, "equipment": ""}, cookie=admin_cookie
        )
        self.assertEqual(status, 201, room)

        general_cookie = self._login("u001", "password01")
        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=general_cookie)
        self.assertEqual(status, 200)
        self.assertIn("結合テスト会議室", [r["name"] for r in rooms])

        status, forbidden, _ = self.server.request(
            "POST", "/api/rooms", {"name": "一般ユーザー作成", "capacity": 2, "equipment": ""}, cookie=general_cookie
        )
        self.assertEqual(status, 403, forbidden)

        today = date.today().isoformat()
        future = (date.today() + timedelta(days=7)).isoformat()
        status, reservations, _ = self.server.request(
            "GET", f"/api/reservations?date_from={today}&date_to={future}", cookie=general_cookie
        )
        self.assertEqual(status, 200)
        self.assertEqual(reservations, [])  # この時点では予約作成APIが未使用のため空

        status, mine, _ = self.server.request(
            "GET", "/api/reservations/mine?period=future", cookie=general_cookie
        )
        self.assertEqual(status, 200)
        self.assertEqual(mine, [])


if __name__ == "__main__":
    unittest.main()
