import unittest
from datetime import date, timedelta

from tests.integration.helpers import LiveServer, session_cookie


class TestU003ReservationFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def _login(self, employee_id, password):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": employee_id, "password": password}
        )
        self.assertEqual(status, 200, body)
        return session_cookie(set_cookie)

    def test_create_conflict_update_cancel(self):
        cookie = self._login("u001", "password01")
        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=cookie)
        room_id = rooms[0]["id"]
        target_date = (date.today() + timedelta(days=2)).isoformat()

        status, created, _ = self.server.request(
            "POST",
            "/api/reservations",
            {
                "room_id": room_id,
                "date": target_date,
                "start_time": "13:00",
                "end_time": "14:00",
                "subject": "結合テスト予約",
                "notes": "",
                "participant_ids": [],
            },
            cookie=cookie,
        )
        self.assertEqual(status, 201, created)
        reservation_id = created["id"]

        status, conflict, _ = self.server.request(
            "POST",
            "/api/reservations",
            {
                "room_id": room_id,
                "date": target_date,
                "start_time": "13:30",
                "end_time": "14:30",
                "subject": "重複するはずの予約",
                "notes": "",
                "participant_ids": [],
            },
            cookie=cookie,
        )
        self.assertEqual(status, 409, conflict)
        self.assertEqual(conflict["error"]["code"], "CONFLICT")

        status, updated, _ = self.server.request(
            "PUT",
            f"/api/reservations/{reservation_id}",
            {
                "room_id": room_id,
                "date": target_date,
                "start_time": "13:00",
                "end_time": "15:00",
                "subject": "結合テスト予約(更新)",
                "notes": "",
                "participant_ids": [],
            },
            cookie=cookie,
        )
        self.assertEqual(status, 200, updated)
        self.assertEqual(updated["end_time"], "15:00")

        status, _, _ = self.server.request(
            "DELETE", f"/api/reservations/{reservation_id}", cookie=cookie
        )
        self.assertEqual(status, 204)

        status, after_delete, _ = self.server.request(
            "GET", f"/api/reservations/{reservation_id}", cookie=cookie
        )
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
