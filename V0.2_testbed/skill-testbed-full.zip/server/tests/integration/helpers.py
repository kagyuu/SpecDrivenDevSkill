"""結合テスト共通ヘルパー: 実サーバー(uvicorn)をサブプロセスで起動しHTTPで検証する。"""
from __future__ import annotations

import http.client
import json
import os
import socket
import subprocess
import sys
import tempfile
import time

SERVER_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class LiveServer:
    def __init__(self):
        self.port = _free_port()
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        env = dict(os.environ)
        env["MRR_DB_PATH"] = self.db_path
        self.process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "app.main:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(self.port),
                "--log-level",
                "warning",
            ],
            cwd=SERVER_DIR,
            env=env,
        )
        self._wait_healthy()

    def _wait_healthy(self, timeout: float = 10.0):
        deadline = time.time() + timeout
        last_err = None
        while time.time() < deadline:
            try:
                conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=1)
                conn.request("GET", "/health")
                resp = conn.getresponse()
                if resp.status == 200:
                    resp.read()
                    return
            except Exception as exc:  # noqa: BLE001
                last_err = exc
            time.sleep(0.2)
        raise RuntimeError(f"live server did not become healthy in time: {last_err}")

    def request(self, method: str, path: str, body: dict | None = None, cookie: str | None = None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        headers = {"Content-Type": "application/json"}
        if cookie:
            headers["Cookie"] = cookie
        payload = json.dumps(body).encode("utf-8") if body is not None else None
        conn.request(method, path, body=payload, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        parsed = json.loads(data) if data else None
        set_cookie = resp.getheader("Set-Cookie")
        status = resp.status
        conn.close()
        return status, parsed, set_cookie

    def stop(self):
        self.process.terminate()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
        if os.path.exists(self.db_path):
            os.remove(self.db_path)


def session_cookie(set_cookie_header: str) -> str:
    """`Set-Cookie` ヘッダから `session_id=...` 部分だけを取り出す。"""
    first = set_cookie_header.split(";")[0]
    return first
