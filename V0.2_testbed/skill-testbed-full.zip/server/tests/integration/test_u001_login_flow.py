import unittest

from tests.integration.helpers import LiveServer, session_cookie


class TestU001LoginFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def test_login_me_logout_me(self):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": "admin", "password": "admin12345"}
        )
        self.assertEqual(status, 200)
        self.assertEqual(body["user"]["role"], "admin")
        cookie = session_cookie(set_cookie)

        status, body, _ = self.server.request("GET", "/api/me", cookie=cookie)
        self.assertEqual(status, 200)
        self.assertEqual(body["role"], "admin")

        status, _, _ = self.server.request("POST", "/api/auth/logout", cookie=cookie)
        self.assertEqual(status, 204)

        status, body, _ = self.server.request("GET", "/api/me", cookie=cookie)
        self.assertEqual(status, 401)


if __name__ == "__main__":
    unittest.main()
