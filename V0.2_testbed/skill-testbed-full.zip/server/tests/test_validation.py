import unittest

from app.validation import time_ranges_overlap, validate_reservation_input


class TestTimeRangesOverlap(unittest.TestCase):
    def test_overlap(self):
        self.assertTrue(time_ranges_overlap("10:00", "11:00", "10:30", "11:30"))

    def test_no_overlap(self):
        self.assertFalse(time_ranges_overlap("10:00", "11:00", "13:00", "14:00"))

    def test_adjacent_is_not_overlap(self):
        self.assertFalse(time_ranges_overlap("10:00", "11:00", "11:00", "12:00"))

    def test_contains(self):
        self.assertTrue(time_ranges_overlap("09:00", "18:00", "10:00", "11:00"))


class TestValidateReservationInput(unittest.TestCase):
    def valid_payload(self):
        return {
            "room_id": 1,
            "date": "2026-08-03",
            "start_time": "10:00",
            "end_time": "11:00",
            "subject": "定例会議",
            "notes": "",
        }

    def test_valid_payload_has_no_errors(self):
        self.assertEqual(validate_reservation_input(self.valid_payload()), [])

    def test_missing_subject(self):
        payload = self.valid_payload()
        payload["subject"] = ""
        errors = validate_reservation_input(payload)
        self.assertIn("件名は必須です", errors)

    def test_end_before_start(self):
        payload = self.valid_payload()
        payload["start_time"] = "12:00"
        payload["end_time"] = "11:00"
        errors = validate_reservation_input(payload)
        self.assertIn("終了時刻は開始時刻より後にしてください", errors)

    def test_subject_too_long(self):
        payload = self.valid_payload()
        payload["subject"] = "a" * 101
        errors = validate_reservation_input(payload)
        self.assertIn("件名は100文字以内で入力してください", errors)

    def test_notes_too_long(self):
        payload = self.valid_payload()
        payload["notes"] = "a" * 501
        errors = validate_reservation_input(payload)
        self.assertIn("備考は500文字以内で入力してください", errors)


if __name__ == "__main__":
    unittest.main()
