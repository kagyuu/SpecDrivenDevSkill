import unittest

from app import db
from app.repositories import rooms as rooms_repo


class TestRoomsRepo(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        db.init_schema(self.conn)

    def tearDown(self):
        self.conn.close()

    def test_create_get_update_deactivate(self):
        created = rooms_repo.create_room(self.conn, "テスト会議室", 5, "モニタ")
        self.assertIsNotNone(created)
        fetched = rooms_repo.get_room(self.conn, created["id"])
        self.assertEqual(fetched["name"], "テスト会議室")

        updated = rooms_repo.update_room(self.conn, created["id"], "テスト会議室2", 6, "モニタ,ホワイトボード", True)
        self.assertEqual(updated["name"], "テスト会議室2")
        self.assertEqual(updated["capacity"], 6)

        rooms_repo.deactivate_room(self.conn, created["id"])
        after = rooms_repo.get_room(self.conn, created["id"])
        self.assertEqual(after["is_active"], 0)

        active_list = rooms_repo.list_rooms(self.conn, include_inactive=False)
        self.assertNotIn(created["id"], [r["id"] for r in active_list])

    def test_name_taken(self):
        rooms_repo.create_room(self.conn, "重複会議室", 4, "")
        self.assertTrue(rooms_repo.name_taken(self.conn, "重複会議室"))
        self.assertFalse(rooms_repo.name_taken(self.conn, "存在しない会議室"))


if __name__ == "__main__":
    unittest.main()
