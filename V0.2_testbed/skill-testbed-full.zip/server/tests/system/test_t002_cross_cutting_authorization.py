import unittest
from datetime import date, timedelta

from tests.integration.helpers import LiveServer, session_cookie


class TestT002CrossCuttingAuthorization(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def _login(self, employee_id, password):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": employee_id, "password": password}
        )
        self.assertEqual(status, 200, body)
        return session_cookie(set_cookie)

    def test_general_user_forbidden_from_admin_endpoints(self):
        admin_cookie = self._login("admin", "admin12345")
        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=admin_cookie)
        room_id = rooms[0]["id"]

        u001_cookie = self._login("u001", "password01")
        u002_cookie = self._login("u002", "password02")

        checks = [
            ("POST", "/api/rooms", {"name": "拒否テスト", "capacity": 1, "equipment": ""}),
            ("PUT", f"/api/rooms/{room_id}", {"name": "拒否テスト", "capacity": 1, "equipment": "", "is_active": True}),
            ("DELETE", f"/api/rooms/{room_id}", None),
            ("GET", "/api/users", None),
            ("POST", "/api/users", {"employee_id": "zz1", "name": "x", "role": "general", "password": "abcdefgh"}),
        ]
        for method, path, body in checks:
            status, resp, _ = self.server.request(method, path, body, cookie=u001_cookie)
            self.assertEqual(status, 403, f"{method} {path} -> {status} {resp}")

        # u002が作成した予約をu001が編集・削除できないこと
        target_date = (date.today() + timedelta(days=4)).isoformat()
        status, created, _ = self.server.request(
            "POST",
            "/api/reservations",
            {
                "room_id": room_id,
                "date": target_date,
                "start_time": "10:00",
                "end_time": "11:00",
                "subject": "u002の予約",
                "notes": "",
                "participant_ids": [],
            },
            cookie=u002_cookie,
        )
        self.assertEqual(status, 201, created)
        rid = created["id"]

        status, resp, _ = self.server.request(
            "PUT",
            f"/api/reservations/{rid}",
            {
                "room_id": room_id,
                "date": target_date,
                "start_time": "10:00",
                "end_time": "12:00",
                "subject": "勝手に変更",
                "notes": "",
                "participant_ids": [],
            },
            cookie=u001_cookie,
        )
        self.assertEqual(status, 403, resp)

        status, resp, _ = self.server.request("DELETE", f"/api/reservations/{rid}", cookie=u001_cookie)
        self.assertEqual(status, 403, resp)


if __name__ == "__main__":
    unittest.main()
