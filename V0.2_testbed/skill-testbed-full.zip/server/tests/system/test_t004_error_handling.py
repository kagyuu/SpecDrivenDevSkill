import http.client
import json
import unittest

from tests.integration.helpers import LiveServer, session_cookie


class TestT004ErrorHandling(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def _login(self):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": "admin", "password": "admin12345"}
        )
        self.assertEqual(status, 200, body)
        return session_cookie(set_cookie)

    def _raw_post(self, path, raw_body: bytes, cookie: str):
        conn = http.client.HTTPConnection("127.0.0.1", self.server.port, timeout=5)
        headers = {"Content-Type": "application/json", "Cookie": cookie}
        conn.request("POST", path, body=raw_body, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        conn.close()
        return resp.status, data

    def test_unknown_path_404(self):
        status, body, _ = self.server.request("GET", "/api/does-not-exist")
        self.assertEqual(status, 404)
        self.assertIn("error", body)

    def test_malformed_json_body(self):
        cookie = self._login()
        status, raw = self._raw_post("/api/reservations", b"not-json-at-all", cookie)
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            parsed = None
        self.malformed_json_status = status
        self.malformed_json_body = parsed
        # 共通エラー形式が維持されているか(崩れていればFAIL)
        self.assertIsNotNone(parsed, f"レスポンスボディがJSONでない(生のトレースバック等が漏れている可能性): {raw[:200]!r}")
        self.assertIn("error", parsed, f"共通エラー形式でない: {parsed}")

    def test_reservation_not_found_404(self):
        cookie = self._login()
        status, body, _ = self.server.request("GET", "/api/reservations/999999", cookie=cookie)
        self.assertEqual(status, 404, body)

    def test_missing_required_fields_400(self):
        cookie = self._login()
        status, body, _ = self.server.request(
            "POST", "/api/reservations", {"room_id": None, "date": "", "start_time": "", "end_time": "", "subject": ""}, cookie=cookie
        )
        self.assertEqual(status, 400, body)
        self.assertIn("error", body)

    def test_reservation_with_nonexistent_participant_returns_validation_error(self):
        """存在しない参加者IDを指定した場合、VALIDATION_ERROR(400)になるべきという期待に対する確認。

        `docs/03-backend-spec.md` 4章は participant_ids の妥当性チェックについて明記していないが、
        `docs/02-frontend-spec.md` 1章 S03 は「参加者(社員): 有効なユーザーのみ選択可能」としており、
        バックエンドでも同等の検証(存在しないユーザーIDはVALIDATION_ERRORとして拒否)が必要と判断する。
        """
        cookie = self._login()
        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=cookie)
        room_id = rooms[0]["id"]
        status, body, _ = self.server.request(
            "POST",
            "/api/reservations",
            {
                "room_id": room_id,
                "date": "2026-08-10",
                "start_time": "10:00",
                "end_time": "11:00",
                "subject": "参加者不正テスト",
                "notes": "",
                "participant_ids": [999999],
            },
            cookie=cookie,
        )
        self.assertEqual(status, 400, f"存在しない参加者IDに対し400(VALIDATION_ERROR)を期待したが{status}が返った: {body}")
        self.assertIn("error", body)


if __name__ == "__main__":
    unittest.main()
