import threading
import unittest
from datetime import date, timedelta

from tests.integration.helpers import LiveServer, session_cookie


class TestT003ConcurrentBooking(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def test_two_simultaneous_bookings_same_slot(self):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": "u001", "password": "password01"}
        )
        self.assertEqual(status, 200, body)
        cookie = session_cookie(set_cookie)

        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=cookie)
        room_id = rooms[0]["id"]
        target_date = (date.today() + timedelta(days=5)).isoformat()

        payload = {
            "room_id": room_id,
            "date": target_date,
            "start_time": "15:00",
            "end_time": "16:00",
            "subject": "同時実行テスト",
            "notes": "",
            "participant_ids": [],
        }

        results = [None, None]

        def worker(idx):
            status, body, _ = self.server.request("POST", "/api/reservations", payload, cookie=cookie)
            results[idx] = status

        t1 = threading.Thread(target=worker, args=(0,))
        t2 = threading.Thread(target=worker, args=(1,))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        self.assertEqual(
            sorted(results), [201, 409], f"期待: 1件201・1件409。実際: {results}"
        )


if __name__ == "__main__":
    unittest.main()
