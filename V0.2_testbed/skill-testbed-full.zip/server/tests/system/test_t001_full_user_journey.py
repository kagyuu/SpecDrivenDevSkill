import unittest
from datetime import date, timedelta

from tests.integration.helpers import LiveServer, session_cookie


class TestT001FullUserJourney(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def _login(self, employee_id, password):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": employee_id, "password": password}
        )
        self.assertEqual(status, 200, body)
        return session_cookie(set_cookie)

    def test_full_journey(self):
        admin_cookie = self._login("admin", "admin12345")
        status, room, _ = self.server.request(
            "POST", "/api/rooms", {"name": "T001会議室", "capacity": 5, "equipment": ""}, cookie=admin_cookie
        )
        self.assertEqual(status, 201, room)

        general_cookie = self._login("u001", "password01")
        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=general_cookie)
        self.assertIn("T001会議室", [r["name"] for r in rooms])

        target_date = (date.today() + timedelta(days=3)).isoformat()
        status, created, _ = self.server.request(
            "POST",
            "/api/reservations",
            {
                "room_id": room["id"],
                "date": target_date,
                "start_time": "09:00",
                "end_time": "10:00",
                "subject": "T001定例MTG",
                "notes": "",
                "participant_ids": [],
            },
            cookie=general_cookie,
        )
        self.assertEqual(status, 201, created)
        rid = created["id"]

        status, calendar, _ = self.server.request(
            "GET",
            f"/api/reservations?date_from={target_date}&date_to={target_date}",
            cookie=general_cookie,
        )
        self.assertEqual(status, 200)
        self.assertIn(rid, [r["id"] for r in calendar])

        status, mine, _ = self.server.request(
            "GET", "/api/reservations/mine?period=future", cookie=general_cookie
        )
        self.assertEqual(status, 200)
        self.assertIn(rid, [r["id"] for r in mine])

        status, updated, _ = self.server.request(
            "PUT",
            f"/api/reservations/{rid}",
            {
                "room_id": room["id"],
                "date": target_date,
                "start_time": "09:00",
                "end_time": "10:00",
                "subject": "T001定例MTG(変更後)",
                "notes": "",
                "participant_ids": [],
            },
            cookie=general_cookie,
        )
        self.assertEqual(status, 200, updated)
        self.assertEqual(updated["subject"], "T001定例MTG(変更後)")

        status, _, _ = self.server.request("DELETE", f"/api/reservations/{rid}", cookie=general_cookie)
        self.assertEqual(status, 204)

        status, _, _ = self.server.request("GET", f"/api/reservations/{rid}", cookie=general_cookie)
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
