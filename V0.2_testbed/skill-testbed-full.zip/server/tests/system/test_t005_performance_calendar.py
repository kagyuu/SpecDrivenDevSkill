import time
import unittest
from datetime import date, timedelta

from tests.integration.helpers import LiveServer, session_cookie


class TestT005PerformanceCalendar(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = LiveServer()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()

    def test_calendar_response_time(self):
        status, body, set_cookie = self.server.request(
            "POST", "/api/auth/login", {"employee_id": "admin", "password": "admin12345"}
        )
        self.assertEqual(status, 200, body)
        cookie = session_cookie(set_cookie)

        status, rooms, _ = self.server.request("GET", "/api/rooms", cookie=cookie)
        room_ids = [r["id"] for r in rooms]

        today = date.today()
        for i in range(20):
            d = (today + timedelta(days=i % 7)).isoformat()
            room_id = room_ids[i % len(room_ids)]
            hour = 8 + (i % 10)
            self.server.request(
                "POST",
                "/api/reservations",
                {
                    "room_id": room_id,
                    "date": d,
                    "start_time": f"{hour:02d}:00",
                    "end_time": f"{hour+1:02d}:00",
                    "subject": f"性能テスト予約{i}",
                    "notes": "",
                    "participant_ids": [],
                },
                cookie=cookie,
            )

        date_from = today.isoformat()
        date_to = (today + timedelta(days=6)).isoformat()

        durations = []
        for _ in range(10):
            start = time.perf_counter()
            status, _, _ = self.server.request(
                "GET", f"/api/reservations?date_from={date_from}&date_to={date_to}", cookie=cookie
            )
            durations.append(time.perf_counter() - start)
            self.assertEqual(status, 200)

        avg = sum(durations) / len(durations)
        mx = max(durations)
        self.avg_seconds = avg
        self.max_seconds = mx
        print(f"\n[T005] avg={avg*1000:.1f}ms max={mx*1000:.1f}ms")
        self.assertLess(avg, 1.0, f"平均応答時間が1秒を超えた: {avg:.3f}s")


if __name__ == "__main__":
    unittest.main()
