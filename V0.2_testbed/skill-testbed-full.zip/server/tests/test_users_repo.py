import unittest

from app import db
from app.repositories import users as users_repo
from app.security import verify_password


class TestUsersRepo(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        db.init_schema(self.conn)

    def tearDown(self):
        self.conn.close()

    def test_create_get_update_deactivate(self):
        created = users_repo.create_user(self.conn, "e100", "テスト花子", "general", "initialpw")
        self.assertEqual(created["employee_id"], "e100")
        self.assertTrue(verify_password("initialpw", created["password_hash"]))

        updated = users_repo.update_user(self.conn, created["id"], "テスト花子2", "admin", True, None)
        self.assertEqual(updated["name"], "テスト花子2")
        self.assertEqual(updated["role"], "admin")
        # パスワード未指定なので変わっていないこと
        self.assertTrue(verify_password("initialpw", updated["password_hash"]))

        updated2 = users_repo.update_user(self.conn, created["id"], "テスト花子2", "admin", True, "newpassword")
        self.assertTrue(verify_password("newpassword", updated2["password_hash"]))

        users_repo.deactivate_user(self.conn, created["id"])
        after = users_repo.get_user(self.conn, created["id"])
        self.assertEqual(after["is_active"], 0)

    def test_employee_id_taken(self):
        users_repo.create_user(self.conn, "e200", "重複太郎", "general", "pw12345678")
        self.assertTrue(users_repo.employee_id_taken(self.conn, "e200"))
        self.assertFalse(users_repo.employee_id_taken(self.conn, "e999"))


if __name__ == "__main__":
    unittest.main()
