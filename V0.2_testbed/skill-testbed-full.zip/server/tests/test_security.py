import unittest
from datetime import datetime, timedelta, timezone

from app import db
from app.security import (
    create_session,
    delete_session,
    get_session_user,
    hash_password,
    verify_password,
)


class TestPasswordHashing(unittest.TestCase):
    def test_verify_correct_password(self):
        hashed = hash_password("correct-horse")
        self.assertTrue(verify_password("correct-horse", hashed))

    def test_verify_wrong_password(self):
        hashed = hash_password("correct-horse")
        self.assertFalse(verify_password("wrong-password", hashed))

    def test_hash_uses_random_salt(self):
        h1 = hash_password("same-password")
        h2 = hash_password("same-password")
        self.assertNotEqual(h1, h2)
        self.assertTrue(verify_password("same-password", h1))
        self.assertTrue(verify_password("same-password", h2))


class TestSession(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        db.init_schema(self.conn)
        self.conn.execute(
            "INSERT INTO users (employee_id, name, password_hash, role, is_active) "
            "VALUES ('u001', 'テスト太郎', ?, 'general', 1)",
            (hash_password("pw"),),
        )
        self.conn.commit()
        self.user_id = self.conn.execute(
            "SELECT id FROM users WHERE employee_id = 'u001'"
        ).fetchone()["id"]

    def tearDown(self):
        self.conn.close()

    def test_session_valid_right_after_creation(self):
        session_id = create_session(self.conn, self.user_id)
        user = get_session_user(self.conn, session_id)
        self.assertIsNotNone(user)
        self.assertEqual(user["id"], self.user_id)

    def test_session_none_when_missing(self):
        self.assertIsNone(get_session_user(self.conn, "does-not-exist"))
        self.assertIsNone(get_session_user(self.conn, None))

    def test_session_expired_returns_none_and_is_deleted(self):
        session_id = create_session(self.conn, self.user_id)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        self.conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?", (past, session_id)
        )
        self.conn.commit()
        self.assertIsNone(get_session_user(self.conn, session_id))
        row = self.conn.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()
        self.assertIsNone(row)

    def test_delete_session(self):
        session_id = create_session(self.conn, self.user_id)
        delete_session(self.conn, session_id)
        self.assertIsNone(get_session_user(self.conn, session_id))


if __name__ == "__main__":
    unittest.main()
