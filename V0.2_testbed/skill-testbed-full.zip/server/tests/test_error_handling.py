import os
import tempfile
import unittest

from starlette.testclient import TestClient

from app.main import create_app


class TestErrorHandling(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(self.db_path)
        self.client = TestClient(self.app)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_unknown_path_returns_404_common_format(self):
        resp = self.client.get("/api/does-not-exist")
        self.assertEqual(resp.status_code, 404)
        self.assertIn("error", resp.json())

    def test_validation_error_returns_400_common_format(self):
        self.client.post("/api/auth/login", json={"employee_id": "admin", "password": "admin12345"})
        resp = self.client.post("/api/rooms", json={"name": "", "capacity": -1})
        self.assertEqual(resp.status_code, 400)
        self.assertIn("error", resp.json())

    def test_health_endpoint(self):
        resp = self.client.get("/health")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["status"], "ok")
        self.assertIn("version", body)


if __name__ == "__main__":
    unittest.main()
