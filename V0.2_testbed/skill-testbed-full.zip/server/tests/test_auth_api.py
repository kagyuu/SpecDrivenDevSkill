import os
import tempfile
import unittest

from starlette.testclient import TestClient

from app.main import create_app


class TestAuthApi(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(self.db_path)
        self.client = TestClient(self.app)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_login_success(self):
        resp = self.client.post("/api/auth/login", json={"employee_id": "admin", "password": "admin12345"})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["user"]["role"], "admin")
        self.assertIn("session_id", resp.cookies)

    def test_login_wrong_password(self):
        resp = self.client.post("/api/auth/login", json={"employee_id": "admin", "password": "wrong"})
        self.assertEqual(resp.status_code, 401)

    def test_login_unknown_user(self):
        resp = self.client.post("/api/auth/login", json={"employee_id": "nobody", "password": "x"})
        self.assertEqual(resp.status_code, 401)

    def test_me_requires_login(self):
        resp = self.client.get("/api/me")
        self.assertEqual(resp.status_code, 401)

    def test_me_after_login(self):
        self.client.post("/api/auth/login", json={"employee_id": "admin", "password": "admin12345"})
        resp = self.client.get("/api/me")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["employee_id"], "admin")

    def test_logout_then_me_unauthorized(self):
        self.client.post("/api/auth/login", json={"employee_id": "admin", "password": "admin12345"})
        resp = self.client.post("/api/auth/logout")
        self.assertEqual(resp.status_code, 204)
        resp2 = self.client.get("/api/me")
        self.assertEqual(resp2.status_code, 401)


if __name__ == "__main__":
    unittest.main()
