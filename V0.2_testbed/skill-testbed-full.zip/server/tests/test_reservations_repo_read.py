import unittest
from datetime import date, timedelta

from app import db
from app.repositories import reservations as res_repo
from app.repositories import rooms as rooms_repo
from app.security import hash_password


class TestReservationsRepoRead(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        db.init_schema(self.conn)
        self.room = rooms_repo.create_room(self.conn, "会議室X", 4, "")
        cur = self.conn.execute(
            "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES ('u100','太郎',?,'general',1)",
            (hash_password("pw"),),
        )
        self.user_id = cur.lastrowid

        self.today = date.today()
        self.future_id = res_repo.create(
            self.conn,
            self.room["id"],
            (self.today + timedelta(days=1)).isoformat(),
            "10:00",
            "11:00",
            "未来の予約",
            "",
            self.user_id,
            [],
        )
        self.past_id = res_repo.create(
            self.conn,
            self.room["id"],
            (self.today - timedelta(days=1)).isoformat(),
            "10:00",
            "11:00",
            "過去の予約",
            "",
            self.user_id,
            [],
        )

    def tearDown(self):
        self.conn.close()

    def test_list_by_range(self):
        rows = res_repo.list_by_range(
            self.conn,
            self.today.isoformat(),
            (self.today + timedelta(days=7)).isoformat(),
            None,
        )
        ids = [r["id"] for r in rows]
        self.assertIn(self.future_id, ids)
        self.assertNotIn(self.past_id, ids)

    def test_list_by_range_room_filter(self):
        other_room = rooms_repo.create_room(self.conn, "会議室Y", 4, "")
        rows = res_repo.list_by_range(
            self.conn,
            self.today.isoformat(),
            (self.today + timedelta(days=7)).isoformat(),
            other_room["id"],
        )
        self.assertEqual(rows, [])

    def test_list_mine_future_and_past(self):
        future_rows = res_repo.list_mine(self.conn, self.user_id, "future")
        past_rows = res_repo.list_mine(self.conn, self.user_id, "past")
        self.assertIn(self.future_id, [r["id"] for r in future_rows])
        self.assertIn(self.past_id, [r["id"] for r in past_rows])

    def test_get_by_id_not_found(self):
        self.assertIsNone(res_repo.get_by_id(self.conn, 999999))

    def test_get_by_id_found(self):
        row = res_repo.get_by_id(self.conn, self.future_id)
        self.assertEqual(row["subject"], "未来の予約")


if __name__ == "__main__":
    unittest.main()
