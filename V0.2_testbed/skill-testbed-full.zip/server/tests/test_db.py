import unittest

from app import db
from app.seed import seed_if_empty


class TestDbSchema(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        db.init_schema(self.conn)

    def tearDown(self):
        self.conn.close()

    def test_all_tables_exist(self):
        tables = {
            row["name"]
            for row in self.conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        expected = {"users", "rooms", "reservations", "reservation_participants", "sessions"}
        self.assertTrue(expected.issubset(tables))

    def test_seed_creates_admin(self):
        seed_if_empty(self.conn)
        admin = self.conn.execute(
            "SELECT * FROM users WHERE employee_id = 'admin'"
        ).fetchone()
        self.assertIsNotNone(admin)
        self.assertEqual(admin["role"], "admin")

    def test_seed_is_idempotent(self):
        seed_if_empty(self.conn)
        seed_if_empty(self.conn)
        count = self.conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
        self.assertEqual(count, 3)


if __name__ == "__main__":
    unittest.main()
