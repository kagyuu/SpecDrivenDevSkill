import unittest
from datetime import date, timedelta

from app import db
from app.repositories import reservations as res_repo
from app.repositories import rooms as rooms_repo
from app.security import hash_password


class TestReservationsRepoWrite(unittest.TestCase):
    def setUp(self):
        self.conn = db.connect(":memory:")
        db.init_schema(self.conn)
        self.room = rooms_repo.create_room(self.conn, "会議室X", 4, "")
        cur = self.conn.execute(
            "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES ('u100','太郎',?,'general',1)",
            (hash_password("pw"),),
        )
        self.user_id = cur.lastrowid
        cur2 = self.conn.execute(
            "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES ('u200','花子',?,'general',1)",
            (hash_password("pw"),),
        )
        self.other_user_id = cur2.lastrowid
        self.date = (date.today() + timedelta(days=1)).isoformat()

    def tearDown(self):
        self.conn.close()

    def test_create_success(self):
        rid = res_repo.create(
            self.conn, self.room["id"], self.date, "10:00", "11:00", "会議", "", self.user_id, []
        )
        row = res_repo.get_by_id(self.conn, rid)
        self.assertEqual(row["subject"], "会議")
        participants = res_repo.get_participant_ids(self.conn, rid)
        self.assertIn(self.user_id, participants)

    def test_create_conflict(self):
        res_repo.create(self.conn, self.room["id"], self.date, "10:00", "11:00", "会議1", "", self.user_id, [])
        with self.assertRaises(ValueError):
            res_repo.create(
                self.conn, self.room["id"], self.date, "10:30", "11:30", "会議2", "", self.user_id, []
            )

    def test_update_excludes_self_from_conflict(self):
        rid = res_repo.create(
            self.conn, self.room["id"], self.date, "10:00", "11:00", "会議", "", self.user_id, []
        )
        # 同じ予約を同じ時間帯で更新しても自分自身とは重複しない
        res_repo.update(
            self.conn, rid, self.room["id"], self.date, "10:00", "11:30", "会議(更新)", "", [], self.user_id
        )
        row = res_repo.get_by_id(self.conn, rid)
        self.assertEqual(row["subject"], "会議(更新)")
        self.assertEqual(row["end_time"], "11:30")

    def test_update_conflicts_with_other_reservation(self):
        res_repo.create(self.conn, self.room["id"], self.date, "09:00", "10:00", "既存予約", "", self.user_id, [])
        rid2 = res_repo.create(
            self.conn, self.room["id"], self.date, "13:00", "14:00", "動かす予約", "", self.user_id, []
        )
        with self.assertRaises(ValueError):
            res_repo.update(
                self.conn, rid2, self.room["id"], self.date, "09:30", "10:30", "動かす予約", "", [], self.user_id
            )

    def test_delete_removes_from_listing(self):
        rid = res_repo.create(
            self.conn, self.room["id"], self.date, "10:00", "11:00", "会議", "", self.user_id, []
        )
        res_repo.delete(self.conn, rid)
        self.assertIsNone(res_repo.get_by_id(self.conn, rid))


if __name__ == "__main__":
    unittest.main()
