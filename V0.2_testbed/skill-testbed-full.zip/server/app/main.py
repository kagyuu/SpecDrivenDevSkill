"""ASGIエントリポイント。

docs/06-impl-direction.md に記載のとおり、FastAPI自体がオフライン環境で取得できないため、
FastAPIの内部基盤であるStarlette + Pydanticを直接用いて同等のREST APIを実装する。
"""
from __future__ import annotations

import os

from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from app import __version__, db
from app.common import ApiError, error_response
from app.routers import auth, reservations, rooms, users
from app.seed import seed_if_empty

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_DB_PATH = os.path.join(BASE_DIR, "data", "app.db")
CLIENT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "client"))


async def health(request):
    return JSONResponse({"status": "ok", "version": __version__})


async def api_error_handler(request, exc: ApiError):
    return error_response(exc.status_code, exc.code, exc.message)


async def not_found_handler(request, exc):
    return error_response(404, "NOT_FOUND", "リソースが見つかりません")


async def server_error_handler(request, exc):
    return error_response(500, "INTERNAL_ERROR", "予期しないエラーが発生しました")


routes = [
    Route("/health", health, methods=["GET"]),
    Route("/api/auth/login", auth.login, methods=["POST"]),
    Route("/api/auth/logout", auth.logout, methods=["POST"]),
    Route("/api/me", auth.me, methods=["GET"]),
    Route("/api/rooms", rooms.list_rooms, methods=["GET"]),
    Route("/api/rooms", rooms.create_room, methods=["POST"]),
    Route("/api/rooms/{room_id:int}", rooms.update_room, methods=["PUT"]),
    Route("/api/rooms/{room_id:int}", rooms.delete_room, methods=["DELETE"]),
    Route("/api/reservations", reservations.list_reservations, methods=["GET"]),
    Route("/api/reservations/mine", reservations.list_mine, methods=["GET"]),
    Route("/api/reservations/{reservation_id:int}", reservations.get_reservation, methods=["GET"]),
    Route("/api/reservations", reservations.create_reservation, methods=["POST"]),
    Route("/api/reservations/{reservation_id:int}", reservations.update_reservation, methods=["PUT"]),
    Route("/api/reservations/{reservation_id:int}", reservations.delete_reservation, methods=["DELETE"]),
    Route("/api/users", users.list_users, methods=["GET"]),
    Route("/api/users", users.create_user, methods=["POST"]),
    Route("/api/users/{user_id:int}", users.update_user, methods=["PUT"]),
    Route("/api/users/{user_id:int}", users.delete_user, methods=["DELETE"]),
]

if os.path.isdir(CLIENT_DIR):
    routes.append(Mount("/", app=StaticFiles(directory=CLIENT_DIR, html=True), name="client"))

exception_handlers = {
    ApiError: api_error_handler,
    404: not_found_handler,
    500: server_error_handler,
}


def create_app(db_path: str | None = None) -> Starlette:
    app = Starlette(routes=routes, exception_handlers=exception_handlers)
    app.state.db_path = db_path or DEFAULT_DB_PATH
    with db.get_conn(app.state.db_path) as conn:
        db.init_schema(conn)
        seed_if_empty(conn)
    return app


app = create_app(os.environ.get("MRR_DB_PATH"))
