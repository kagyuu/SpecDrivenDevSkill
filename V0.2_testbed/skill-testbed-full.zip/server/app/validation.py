"""予約入力の純粋関数バリデーション・重複判定。docs/03-backend-spec.md 4章「予約系」参照。"""
from __future__ import annotations

from datetime import datetime


def time_ranges_overlap(start1: str, end1: str, start2: str, end2: str) -> bool:
    """2つの時間帯(HH:MM文字列)が重複するか判定する。境界が接するだけ(隣接)は重複としない。"""
    return not (end1 <= start2 or start1 >= end2)


def _valid_time_format(value: str) -> bool:
    try:
        datetime.strptime(value, "%H:%M")
        return True
    except (ValueError, TypeError):
        return False


def _valid_date_format(value: str) -> bool:
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return True
    except (ValueError, TypeError):
        return False


def validate_reservation_input(payload: dict) -> list[str]:
    """予約作成/更新入力を検証し、エラーメッセージのリストを返す(空リストなら妥当)。"""
    errors: list[str] = []

    subject = payload.get("subject") or ""
    if not subject.strip():
        errors.append("件名は必須です")
    elif len(subject) > 100:
        errors.append("件名は100文字以内で入力してください")

    notes = payload.get("notes") or ""
    if len(notes) > 500:
        errors.append("備考は500文字以内で入力してください")

    date = payload.get("date") or ""
    if not _valid_date_format(date):
        errors.append("日付の形式が不正です")

    start_time = payload.get("start_time") or ""
    end_time = payload.get("end_time") or ""
    if not _valid_time_format(start_time):
        errors.append("開始時刻の形式が不正です")
    if not _valid_time_format(end_time):
        errors.append("終了時刻の形式が不正です")
    if _valid_time_format(start_time) and _valid_time_format(end_time) and end_time <= start_time:
        errors.append("終了時刻は開始時刻より後にしてください")

    if not payload.get("room_id"):
        errors.append("会議室は必須です")

    return errors
