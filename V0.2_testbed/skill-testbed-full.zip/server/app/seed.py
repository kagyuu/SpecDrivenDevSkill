"""開発・検証用初期データ投入。"""
from __future__ import annotations

import sqlite3

from app.security import hash_password


def seed_if_empty(conn: sqlite3.Connection) -> None:
    count = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    if count > 0:
        return

    conn.execute(
        "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)",
        ("admin", "管理 太郎", hash_password("admin12345"), "admin"),
    )
    conn.execute(
        "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)",
        ("u001", "山田 花子", hash_password("password01"), "general"),
    )
    conn.execute(
        "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)",
        ("u002", "佐藤 次郎", hash_password("password02"), "general"),
    )

    for name, capacity, equipment in [
        ("会議室A", 4, "ホワイトボード"),
        ("会議室B", 8, "プロジェクタ,ホワイトボード"),
        ("会議室C", 12, "プロジェクタ,Web会議用カメラ"),
    ]:
        conn.execute(
            "INSERT INTO rooms (name, capacity, equipment, is_active) VALUES (?, ?, ?, 1)",
            (name, capacity, equipment),
        )
    conn.commit()
