"""パスワードハッシュ・セッション管理。

docs/03-backend-spec.md 3章に対応する。
"""
from __future__ import annotations

import binascii
import hashlib
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone

SESSION_LIFETIME_HOURS = 8
_PBKDF2_ITERATIONS = 100_000


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _PBKDF2_ITERATIONS)
    return f"{binascii.hexlify(salt).decode()}:{binascii.hexlify(dk).decode()}"


def verify_password(password: str, hashed: str) -> bool:
    try:
        salt_hex, dk_hex = hashed.split(":", 1)
    except ValueError:
        return False
    salt = binascii.unhexlify(salt_hex)
    expected = binascii.unhexlify(dk_hex)
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _PBKDF2_ITERATIONS)
    return secrets.compare_digest(expected, actual)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def create_session(conn: sqlite3.Connection, user_id: int) -> str:
    session_id = secrets.token_urlsafe(32)
    created_at = _now()
    expires_at = created_at + timedelta(hours=SESSION_LIFETIME_HOURS)
    conn.execute(
        "INSERT INTO sessions (session_id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
        (session_id, user_id, created_at.isoformat(), expires_at.isoformat()),
    )
    conn.commit()
    return session_id


def get_session_user(conn: sqlite3.Connection, session_id: str | None) -> sqlite3.Row | None:
    if not session_id:
        return None
    row = conn.execute(
        "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
    ).fetchone()
    if row is None:
        return None
    expires_at = datetime.fromisoformat(row["expires_at"])
    if expires_at < _now():
        conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        conn.commit()
        return None
    user = conn.execute(
        "SELECT * FROM users WHERE id = ? AND is_active = 1", (row["user_id"],)
    ).fetchone()
    return user


def delete_session(conn: sqlite3.Connection, session_id: str) -> None:
    conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
    conn.commit()
