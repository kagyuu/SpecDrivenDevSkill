"""ユーザーAPI: GET/POST/PUT/DELETE /api/users (管理者のみ)

docs/02-frontend-spec.md 2章、docs/03-backend-spec.md 4章「ユーザー系」に対応する。
"""
from __future__ import annotations

from pydantic import ValidationError
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app import db
from app.common import ApiError, error_response, require_admin
from app.repositories import users as users_repo
from app.schemas import UserIn, UserUpdateIn


def _user_out(row) -> dict:
    return {
        "id": row["id"],
        "employee_id": row["employee_id"],
        "name": row["name"],
        "role": row["role"],
        "is_active": bool(row["is_active"]),
    }


async def list_users(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        rows = users_repo.list_users(conn)
        return JSONResponse([_user_out(r) for r in rows])


async def create_user(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        try:
            payload = UserIn.model_validate(await request.json())
        except ValidationError as exc:
            return error_response(400, "VALIDATION_ERROR", str(exc))
        if payload.role not in ("general", "admin"):
            return error_response(400, "VALIDATION_ERROR", "roleはgeneralまたはadminです")
        if users_repo.employee_id_taken(conn, payload.employee_id):
            return error_response(400, "VALIDATION_ERROR", "同じ社員IDのユーザーが既に存在します")
        row = users_repo.create_user(conn, payload.employee_id, payload.name, payload.role, payload.password)
        return JSONResponse(_user_out(row), status_code=201)


async def update_user(request: Request) -> Response:
    user_id = int(request.path_params["user_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        existing = users_repo.get_user(conn, user_id)
        if existing is None:
            return error_response(404, "NOT_FOUND", "ユーザーが見つかりません")
        try:
            payload = UserUpdateIn.model_validate(await request.json())
        except ValidationError as exc:
            return error_response(400, "VALIDATION_ERROR", str(exc))
        if payload.role not in ("general", "admin"):
            return error_response(400, "VALIDATION_ERROR", "roleはgeneralまたはadminです")
        row = users_repo.update_user(conn, user_id, payload.name, payload.role, payload.is_active, payload.password)
        return JSONResponse(_user_out(row))


async def delete_user(request: Request) -> Response:
    user_id = int(request.path_params["user_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        existing = users_repo.get_user(conn, user_id)
        if existing is None:
            return error_response(404, "NOT_FOUND", "ユーザーが見つかりません")
        users_repo.deactivate_user(conn, user_id)
        return Response(status_code=204)
