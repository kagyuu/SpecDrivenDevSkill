"""認証系API: POST /api/auth/login, POST /api/auth/logout, GET /api/me

docs/02-frontend-spec.md 2章、docs/03-backend-spec.md 3章に対応する。
"""
from __future__ import annotations

from pydantic import ValidationError
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app import db, security
from app.common import ApiError, current_user, error_response, require_login
from app.schemas import LoginRequest, UserOut


def _user_out(row) -> dict:
    return UserOut(
        id=row["id"], employee_id=row["employee_id"], name=row["name"], role=row["role"]
    ).model_dump()


async def login(request: Request) -> Response:
    body = await request.json()
    try:
        payload = LoginRequest.model_validate(body)
    except ValidationError as exc:
        return error_response(400, "VALIDATION_ERROR", str(exc))

    with db.get_conn(request.app.state.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE employee_id = ? AND is_active = 1",
            (payload.employee_id,),
        ).fetchone()
        if row is None or not security.verify_password(payload.password, row["password_hash"]):
            return error_response(401, "UNAUTHORIZED", "ユーザーIDまたはパスワードが違います")

        session_id = security.create_session(conn, row["id"])
        resp = JSONResponse({"user": _user_out(row)})
        resp.set_cookie("session_id", session_id, httponly=True, samesite="lax")
        return resp


async def logout(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        session_id = request.cookies.get("session_id")
        security.delete_session(conn, session_id)
        resp = Response(status_code=204)
        resp.delete_cookie("session_id")
        return resp


async def me(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        user = current_user(request, conn)
        if user is None:
            return error_response(401, "UNAUTHORIZED", "ログインが必要です")
        return JSONResponse(_user_out(user))
