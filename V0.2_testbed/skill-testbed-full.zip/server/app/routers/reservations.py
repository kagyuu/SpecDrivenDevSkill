"""予約API: GET/POST/PUT/DELETE /api/reservations, /mine

docs/02-frontend-spec.md 2章、docs/03-backend-spec.md 4章「予約系」に対応する。
"""
from __future__ import annotations

from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app import db
from app.common import ApiError, error_response, require_login
from app.repositories import reservations as res_repo
from app.repositories import rooms as rooms_repo
from app.validation import validate_reservation_input


def _reservation_out(row, participant_ids: list[int]) -> dict:
    return {
        "id": row["id"],
        "room_id": row["room_id"],
        "room_name": row["room_name"],
        "date": row["date"],
        "start_time": row["start_time"],
        "end_time": row["end_time"],
        "subject": row["subject"],
        "notes": row["notes"] or "",
        "created_by": row["created_by"],
        "created_by_name": row["created_by_name"],
        "participant_ids": participant_ids,
    }


def _list_out(rows) -> list[dict]:
    return [
        {
            "id": r["id"],
            "room_id": r["room_id"],
            "room_name": r["room_name"],
            "date": r["date"],
            "start_time": r["start_time"],
            "end_time": r["end_time"],
            "subject": r["subject"],
            "created_by": r["created_by"],
            "created_by_name": r["created_by_name"],
        }
        for r in rows
    ]


async def list_reservations(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        date_from = request.query_params.get("date_from")
        date_to = request.query_params.get("date_to")
        if not date_from or not date_to or date_from > date_to:
            return error_response(400, "VALIDATION_ERROR", "date_from/date_to が不正です")
        room_id = request.query_params.get("room_id")
        room_id = int(room_id) if room_id else None
        rows = res_repo.list_by_range(conn, date_from, date_to, room_id)
        return JSONResponse(_list_out(rows))


async def list_mine(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            user = require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        period = request.query_params.get("period", "future")
        rows = res_repo.list_mine(conn, user["id"], period)
        return JSONResponse(_list_out(rows))


async def get_reservation(request: Request) -> Response:
    reservation_id = int(request.path_params["reservation_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        row = res_repo.get_by_id(conn, reservation_id)
        if row is None:
            return error_response(404, "NOT_FOUND", "予約が見つかりません")
        participant_ids = res_repo.get_participant_ids(conn, reservation_id)
        return JSONResponse(_reservation_out(row, participant_ids))


async def create_reservation(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            user = require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        payload = await request.json()
        errors = validate_reservation_input(payload)
        if errors:
            return error_response(400, "VALIDATION_ERROR", "; ".join(errors))
        room = rooms_repo.get_room(conn, payload["room_id"])
        if room is None or not room["is_active"]:
            return error_response(404, "NOT_FOUND", "会議室が見つかりません")
        missing = res_repo.find_missing_participant_ids(conn, payload.get("participant_ids") or [])
        if missing:
            return error_response(
                400, "VALIDATION_ERROR", f"存在しない、または無効な参加者IDが指定されています: {missing}"
            )
        try:
            reservation_id = res_repo.create(
                conn,
                payload["room_id"],
                payload["date"],
                payload["start_time"],
                payload["end_time"],
                payload["subject"],
                payload.get("notes") or "",
                user["id"],
                payload.get("participant_ids") or [],
            )
        except ValueError:
            return error_response(409, "CONFLICT", "指定の時間帯は既に予約されています")
        row = res_repo.get_by_id(conn, reservation_id)
        participant_ids = res_repo.get_participant_ids(conn, reservation_id)
        return JSONResponse(_reservation_out(row, participant_ids), status_code=201)


async def update_reservation(request: Request) -> Response:
    reservation_id = int(request.path_params["reservation_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            user = require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        existing = res_repo.get_by_id(conn, reservation_id)
        if existing is None:
            return error_response(404, "NOT_FOUND", "予約が見つかりません")
        if existing["created_by"] != user["id"] and user["role"] != "admin":
            return error_response(403, "FORBIDDEN", "この予約を編集する権限がありません")
        payload = await request.json()
        errors = validate_reservation_input(payload)
        if errors:
            return error_response(400, "VALIDATION_ERROR", "; ".join(errors))
        room = rooms_repo.get_room(conn, payload["room_id"])
        if room is None or not room["is_active"]:
            return error_response(404, "NOT_FOUND", "会議室が見つかりません")
        missing = res_repo.find_missing_participant_ids(conn, payload.get("participant_ids") or [])
        if missing:
            return error_response(
                400, "VALIDATION_ERROR", f"存在しない、または無効な参加者IDが指定されています: {missing}"
            )
        try:
            res_repo.update(
                conn,
                reservation_id,
                payload["room_id"],
                payload["date"],
                payload["start_time"],
                payload["end_time"],
                payload["subject"],
                payload.get("notes") or "",
                payload.get("participant_ids") or [],
                existing["created_by"],
            )
        except ValueError:
            return error_response(409, "CONFLICT", "指定の時間帯は既に予約されています")
        row = res_repo.get_by_id(conn, reservation_id)
        participant_ids = res_repo.get_participant_ids(conn, reservation_id)
        return JSONResponse(_reservation_out(row, participant_ids))


async def delete_reservation(request: Request) -> Response:
    reservation_id = int(request.path_params["reservation_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            user = require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        existing = res_repo.get_by_id(conn, reservation_id)
        if existing is None:
            return error_response(404, "NOT_FOUND", "予約が見つかりません")
        if existing["created_by"] != user["id"] and user["role"] != "admin":
            return error_response(403, "FORBIDDEN", "この予約を取消する権限がありません")
        res_repo.delete(conn, reservation_id)
        return Response(status_code=204)
