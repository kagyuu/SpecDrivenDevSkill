"""会議室API: GET/POST/PUT/DELETE /api/rooms

docs/02-frontend-spec.md 2章、docs/03-backend-spec.md 4章「会議室系」に対応する。
"""
from __future__ import annotations

from pydantic import ValidationError
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app import db
from app.common import ApiError, error_response, require_admin, require_login
from app.repositories import rooms as rooms_repo
from app.schemas import RoomIn, RoomOut, RoomUpdateIn


def _room_out(row) -> dict:
    return RoomOut(
        id=row["id"],
        name=row["name"],
        capacity=row["capacity"],
        equipment=row["equipment"] or "",
        is_active=bool(row["is_active"]),
    ).model_dump()


async def list_rooms(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            user = require_login(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        include_inactive = request.query_params.get("include_inactive") == "true" and user["role"] == "admin"
        rows = rooms_repo.list_rooms(conn, include_inactive=include_inactive)
        return JSONResponse([_room_out(r) for r in rows])


async def create_room(request: Request) -> Response:
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        try:
            payload = RoomIn.model_validate(await request.json())
        except ValidationError as exc:
            return error_response(400, "VALIDATION_ERROR", str(exc))
        if rooms_repo.name_taken(conn, payload.name):
            return error_response(400, "VALIDATION_ERROR", "同名の会議室が既に存在します")
        row = rooms_repo.create_room(conn, payload.name, payload.capacity, payload.equipment or "")
        return JSONResponse(_room_out(row), status_code=201)


async def update_room(request: Request) -> Response:
    room_id = int(request.path_params["room_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        existing = rooms_repo.get_room(conn, room_id)
        if existing is None:
            return error_response(404, "NOT_FOUND", "会議室が見つかりません")
        try:
            payload = RoomUpdateIn.model_validate(await request.json())
        except ValidationError as exc:
            return error_response(400, "VALIDATION_ERROR", str(exc))
        if rooms_repo.name_taken(conn, payload.name, exclude_id=room_id):
            return error_response(400, "VALIDATION_ERROR", "同名の会議室が既に存在します")
        row = rooms_repo.update_room(
            conn, room_id, payload.name, payload.capacity, payload.equipment or "", payload.is_active
        )
        return JSONResponse(_room_out(row))


async def delete_room(request: Request) -> Response:
    room_id = int(request.path_params["room_id"])
    with db.get_conn(request.app.state.db_path) as conn:
        try:
            require_admin(request, conn)
        except ApiError as exc:
            return error_response(exc.status_code, exc.code, exc.message)
        existing = rooms_repo.get_room(conn, room_id)
        if existing is None:
            return error_response(404, "NOT_FOUND", "会議室が見つかりません")
        rooms_repo.deactivate_room(conn, room_id)
        return Response(status_code=204)
