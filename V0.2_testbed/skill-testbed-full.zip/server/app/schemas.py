"""Pydanticスキーマ(レスポンス整形・入力バリデーションの一部)。"""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    employee_id: str
    password: str


class UserOut(BaseModel):
    id: int
    employee_id: str
    name: str
    role: str


class RoomIn(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    capacity: int = Field(gt=0)
    equipment: Optional[str] = ""


class RoomUpdateIn(RoomIn):
    is_active: bool = True


class RoomOut(BaseModel):
    id: int
    name: str
    capacity: int
    equipment: Optional[str]
    is_active: bool


class ReservationIn(BaseModel):
    room_id: int
    date: str
    start_time: str
    end_time: str
    subject: str = Field(min_length=1, max_length=100)
    notes: Optional[str] = Field(default="", max_length=500)
    participant_ids: list[int] = Field(default_factory=list)


class UserIn(BaseModel):
    employee_id: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=1, max_length=50)
    role: str
    password: str = Field(min_length=8, max_length=72)


class UserUpdateIn(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    role: str
    is_active: bool = True
    password: Optional[str] = None
