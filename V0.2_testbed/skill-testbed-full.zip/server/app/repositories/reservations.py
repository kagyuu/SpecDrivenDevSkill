"""予約(reservations)テーブルへのアクセス。docs/03-backend-spec.md 4章「予約系」参照。"""
from __future__ import annotations

import sqlite3
from datetime import date as date_cls

from app.validation import time_ranges_overlap

_SELECT_BASE = """
SELECT r.*, rm.name AS room_name, u.name AS created_by_name
FROM reservations r
JOIN rooms rm ON rm.id = r.room_id
JOIN users u ON u.id = r.created_by
"""


def list_by_range(conn: sqlite3.Connection, date_from: str, date_to: str, room_id: int | None) -> list[sqlite3.Row]:
    sql = _SELECT_BASE + " WHERE r.date >= ? AND r.date <= ?"
    params: list = [date_from, date_to]
    if room_id is not None:
        sql += " AND r.room_id = ?"
        params.append(room_id)
    sql += " ORDER BY r.date, r.start_time"
    return conn.execute(sql, params).fetchall()


def list_mine(conn: sqlite3.Connection, user_id: int, period: str) -> list[sqlite3.Row]:
    today = date_cls.today().isoformat()
    op = ">=" if period != "past" else "<"
    sql = _SELECT_BASE + f" WHERE r.created_by = ? AND r.date {op} ? ORDER BY r.date, r.start_time"
    return conn.execute(sql, (user_id, today)).fetchall()


def get_by_id(conn: sqlite3.Connection, reservation_id: int) -> sqlite3.Row | None:
    return conn.execute(_SELECT_BASE + " WHERE r.id = ?", (reservation_id,)).fetchone()


def get_participant_ids(conn: sqlite3.Connection, reservation_id: int) -> list[int]:
    rows = conn.execute(
        "SELECT user_id FROM reservation_participants WHERE reservation_id = ?", (reservation_id,)
    ).fetchall()
    return [r["user_id"] for r in rows]


def find_missing_participant_ids(conn: sqlite3.Connection, participant_ids: list[int]) -> list[int]:
    """存在しない、または無効化されたユーザーIDを抽出する(F001修正: 参加者IDの実在チェック)。"""
    missing = []
    for uid in set(participant_ids):
        row = conn.execute("SELECT 1 FROM users WHERE id = ? AND is_active = 1", (uid,)).fetchone()
        if row is None:
            missing.append(uid)
    return missing


def has_conflict(
    conn: sqlite3.Connection,
    room_id: int,
    date: str,
    start_time: str,
    end_time: str,
    exclude_id: int | None = None,
) -> bool:
    rows = conn.execute(
        "SELECT id, start_time, end_time FROM reservations WHERE room_id = ? AND date = ?",
        (room_id, date),
    ).fetchall()
    for row in rows:
        if exclude_id is not None and row["id"] == exclude_id:
            continue
        if time_ranges_overlap(start_time, end_time, row["start_time"], row["end_time"]):
            return True
    return False


def create(
    conn: sqlite3.Connection,
    room_id: int,
    date: str,
    start_time: str,
    end_time: str,
    subject: str,
    notes: str,
    created_by: int,
    participant_ids: list[int],
) -> int:
    """`BEGIN IMMEDIATE` トランザクション内で重複再チェック + INSERT を行う。

    重複していれば ValueError("CONFLICT") を送出しロールバックする。
    """
    conn.execute("BEGIN IMMEDIATE")
    try:
        if has_conflict(conn, room_id, date, start_time, end_time):
            conn.execute("ROLLBACK")
            raise ValueError("CONFLICT")
        cur = conn.execute(
            "INSERT INTO reservations (room_id, date, start_time, end_time, subject, notes, created_by) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (room_id, date, start_time, end_time, subject, notes, created_by),
        )
        reservation_id = cur.lastrowid
        participants = set(participant_ids) | {created_by}
        for uid in participants:
            conn.execute(
                "INSERT INTO reservation_participants (reservation_id, user_id) VALUES (?, ?)",
                (reservation_id, uid),
            )
        conn.execute("COMMIT")
        return reservation_id
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.OperationalError:
            pass
        raise


def update(
    conn: sqlite3.Connection,
    reservation_id: int,
    room_id: int,
    date: str,
    start_time: str,
    end_time: str,
    subject: str,
    notes: str,
    participant_ids: list[int],
    owner_id: int,
) -> None:
    conn.execute("BEGIN IMMEDIATE")
    try:
        if has_conflict(conn, room_id, date, start_time, end_time, exclude_id=reservation_id):
            conn.execute("ROLLBACK")
            raise ValueError("CONFLICT")
        conn.execute(
            "UPDATE reservations SET room_id=?, date=?, start_time=?, end_time=?, subject=?, notes=? WHERE id=?",
            (room_id, date, start_time, end_time, subject, notes, reservation_id),
        )
        conn.execute("DELETE FROM reservation_participants WHERE reservation_id = ?", (reservation_id,))
        participants = set(participant_ids) | {owner_id}
        for uid in participants:
            conn.execute(
                "INSERT INTO reservation_participants (reservation_id, user_id) VALUES (?, ?)",
                (reservation_id, uid),
            )
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.OperationalError:
            pass
        raise


def delete(conn: sqlite3.Connection, reservation_id: int) -> None:
    conn.execute("DELETE FROM reservation_participants WHERE reservation_id = ?", (reservation_id,))
    conn.execute("DELETE FROM reservations WHERE id = ?", (reservation_id,))
    conn.commit()
