"""ユーザー(users)テーブルへのアクセス。docs/03-backend-spec.md 4章「ユーザー系」参照。"""
from __future__ import annotations

import sqlite3

from app.security import hash_password


def list_users(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM users ORDER BY id").fetchall()


def get_user(conn: sqlite3.Connection, user_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def employee_id_taken(conn: sqlite3.Connection, employee_id: str) -> bool:
    row = conn.execute("SELECT 1 FROM users WHERE employee_id = ?", (employee_id,)).fetchone()
    return row is not None


def create_user(conn: sqlite3.Connection, employee_id: str, name: str, role: str, password: str) -> sqlite3.Row:
    cur = conn.execute(
        "INSERT INTO users (employee_id, name, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)",
        (employee_id, name, hash_password(password), role),
    )
    return get_user(conn, cur.lastrowid)


def update_user(
    conn: sqlite3.Connection,
    user_id: int,
    name: str,
    role: str,
    is_active: bool,
    password: str | None,
) -> sqlite3.Row | None:
    if password:
        conn.execute(
            "UPDATE users SET name=?, role=?, is_active=?, password_hash=? WHERE id=?",
            (name, role, 1 if is_active else 0, hash_password(password), user_id),
        )
    else:
        conn.execute(
            "UPDATE users SET name=?, role=?, is_active=? WHERE id=?",
            (name, role, 1 if is_active else 0, user_id),
        )
    return get_user(conn, user_id)


def deactivate_user(conn: sqlite3.Connection, user_id: int) -> None:
    conn.execute("UPDATE users SET is_active = 0 WHERE id = ?", (user_id,))
