"""会議室(rooms)テーブルへのアクセス。docs/03-backend-spec.md 4章「会議室系」参照。"""
from __future__ import annotations

import sqlite3


def list_rooms(conn: sqlite3.Connection, include_inactive: bool = False) -> list[sqlite3.Row]:
    if include_inactive:
        return conn.execute("SELECT * FROM rooms ORDER BY id").fetchall()
    return conn.execute("SELECT * FROM rooms WHERE is_active = 1 ORDER BY id").fetchall()


def get_room(conn: sqlite3.Connection, room_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM rooms WHERE id = ?", (room_id,)).fetchone()


def name_taken(conn: sqlite3.Connection, name: str, exclude_id: int | None = None) -> bool:
    if exclude_id is None:
        row = conn.execute(
            "SELECT 1 FROM rooms WHERE name = ? AND is_active = 1", (name,)
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT 1 FROM rooms WHERE name = ? AND is_active = 1 AND id != ?",
            (name, exclude_id),
        ).fetchone()
    return row is not None


def create_room(conn: sqlite3.Connection, name: str, capacity: int, equipment: str) -> sqlite3.Row:
    cur = conn.execute(
        "INSERT INTO rooms (name, capacity, equipment, is_active) VALUES (?, ?, ?, 1)",
        (name, capacity, equipment),
    )
    conn.commit()
    return get_room(conn, cur.lastrowid)


def update_room(
    conn: sqlite3.Connection, room_id: int, name: str, capacity: int, equipment: str, is_active: bool
) -> sqlite3.Row | None:
    conn.execute(
        "UPDATE rooms SET name = ?, capacity = ?, equipment = ?, is_active = ? WHERE id = ?",
        (name, capacity, equipment, 1 if is_active else 0, room_id),
    )
    conn.commit()
    return get_room(conn, room_id)


def deactivate_room(conn: sqlite3.Connection, room_id: int) -> None:
    conn.execute("UPDATE rooms SET is_active = 0 WHERE id = ?", (room_id,))
    conn.commit()
