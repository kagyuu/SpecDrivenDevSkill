"""ルータ共通ヘルパー(エラーレスポンス・認証/認可チェック)。

docs/03-backend-spec.md 5章(エラーハンドリング共通方針)に対応する。
"""
from __future__ import annotations

import sqlite3

from starlette.requests import Request
from starlette.responses import JSONResponse

from app import security


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str):
        self.status_code = status_code
        self.code = code
        self.message = message


def error_response(status_code: int, code: str, message: str) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "message": message}}, status_code=status_code)


def current_user(request: Request, conn: sqlite3.Connection) -> sqlite3.Row | None:
    session_id = request.cookies.get("session_id")
    return security.get_session_user(conn, session_id)


def require_login(request: Request, conn: sqlite3.Connection) -> sqlite3.Row:
    user = current_user(request, conn)
    if user is None:
        raise ApiError(401, "UNAUTHORIZED", "ログインが必要です")
    return user


def require_admin(request: Request, conn: sqlite3.Connection) -> sqlite3.Row:
    user = require_login(request, conn)
    if user["role"] != "admin":
        raise ApiError(403, "FORBIDDEN", "管理者権限が必要です")
    return user
