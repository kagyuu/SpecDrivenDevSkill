// 共通APIクライアント。docs/02-frontend-spec.md 2章の外部仕様に対応する。
export async function apiFetch(path, { method = "GET", body } = {}) {
  const res = await fetch(path, {
    method,
    credentials: "include",
    headers: body !== undefined ? { "Content-Type": "application/json" } : {},
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = null;
  const text = await res.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      data = null;
    }
  }
  if (!res.ok) {
    const message = data && data.error ? data.error.message : `エラーが発生しました (${res.status})`;
    const err = new Error(message);
    err.status = res.status;
    err.body = data;
    throw err;
  }
  return data;
}

export const api = {
  login: (employee_id, password) => apiFetch("/api/auth/login", { method: "POST", body: { employee_id, password } }),
  logout: () => apiFetch("/api/auth/logout", { method: "POST" }),
  me: () => apiFetch("/api/me"),
  rooms: () => apiFetch("/api/rooms"),
  createRoom: (payload) => apiFetch("/api/rooms", { method: "POST", body: payload }),
  updateRoom: (id, payload) => apiFetch(`/api/rooms/${id}`, { method: "PUT", body: payload }),
  deleteRoom: (id) => apiFetch(`/api/rooms/${id}`, { method: "DELETE" }),
  reservations: (dateFrom, dateTo, roomId) => {
    const q = new URLSearchParams({ date_from: dateFrom, date_to: dateTo });
    if (roomId) q.set("room_id", roomId);
    return apiFetch(`/api/reservations?${q.toString()}`);
  },
  myReservations: (period) => apiFetch(`/api/reservations/mine?period=${period}`),
  reservation: (id) => apiFetch(`/api/reservations/${id}`),
  createReservation: (payload) => apiFetch("/api/reservations", { method: "POST", body: payload }),
  updateReservation: (id, payload) => apiFetch(`/api/reservations/${id}`, { method: "PUT", body: payload }),
  deleteReservation: (id) => apiFetch(`/api/reservations/${id}`, { method: "DELETE" }),
  users: () => apiFetch("/api/users"),
  createUser: (payload) => apiFetch("/api/users", { method: "POST", body: payload }),
  updateUser: (id, payload) => apiFetch(`/api/users/${id}`, { method: "PUT", body: payload }),
  deleteUser: (id) => apiFetch(`/api/users/${id}`, { method: "DELETE" }),
};
