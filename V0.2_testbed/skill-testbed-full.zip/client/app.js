import { api } from "./api.js";

const appEl = document.getElementById("app");
const navEl = document.getElementById("main-nav");

let currentUser = null;
let roomsCache = [];
let weekStart = startOfWeek(new Date());

function startOfWeek(d) {
  const date = new Date(d);
  const day = date.getDay();
  date.setDate(date.getDate() - day);
  date.setHours(0, 0, 0, 0);
  return date;
}
function fmtDate(d) {
  return d.toISOString().slice(0, 10);
}
function addDays(d, n) {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

function navigate(hash) {
  window.location.hash = hash;
}
window.navigate = navigate;

function renderNav() {
  if (!currentUser) {
    navEl.innerHTML = "";
    return;
  }
  const links = [
    ["#/calendar", "予約カレンダー"],
    ["#/mine", "マイ予約"],
  ];
  if (currentUser.role === "admin") {
    links.push(["#/rooms", "会議室管理"]);
    links.push(["#/users", "ユーザー管理"]);
  }
  navEl.innerHTML =
    links.map(([href, label]) => `<a href="${href}">${label}</a>`).join("") +
    ` <a href="#" id="logout-link">ログアウト (${escapeHtml(currentUser.name)})</a>`;
  document.getElementById("logout-link").onclick = async (e) => {
    e.preventDefault();
    await api.logout();
    currentUser = null;
    navigate("#/login");
  };
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function ensureLoggedIn() {
  if (currentUser) return true;
  try {
    currentUser = await api.me();
    return true;
  } catch (e) {
    return false;
  }
}

async function router() {
  const hash = window.location.hash || "#/login";
  const [, path, param] = hash.match(/^#\/(\w+)\/?(.*)$/) || [null, "login", ""];

  if (path !== "login") {
    const ok = await ensureLoggedIn();
    if (!ok) {
      navigate("#/login");
      return;
    }
  }
  renderNav();

  try {
    if (path === "login") return renderLogin();
    if (path === "calendar") return await renderCalendar();
    if (path === "reservations" && param === "new") return await renderReservationForm();
    if (path === "reservations" && param) return await renderReservationDetail(param);
    if (path === "mine") return await renderMyReservations();
    if (path === "rooms") return await renderRoomsAdmin();
    if (path === "users") return await renderUsersAdmin();
    appEl.innerHTML = "<p>ページが見つかりません。</p>";
  } catch (e) {
    appEl.innerHTML = `<p class="error">${escapeHtml(e.message)}</p>`;
  }
}

// ---------- S01 ログイン画面 ----------
function renderLogin() {
  appEl.innerHTML = `
    <h2>ログイン</h2>
    <form id="login-form">
      <label>ユーザーID<input type="text" name="employee_id" required maxlength="20"></label>
      <label>パスワード<input type="password" name="password" required></label>
      <div class="error" id="login-error"></div>
      <button type="submit">ログイン</button>
    </form>
    <p class="hint">デモ用アカウント: admin/admin12345(管理者), u001/password01(一般)</p>
  `;
  document.getElementById("login-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const res = await api.login(fd.get("employee_id"), fd.get("password"));
      currentUser = res.user;
      navigate("#/calendar");
    } catch (err) {
      document.getElementById("login-error").textContent = err.message;
    }
  };
}

// ---------- S02 予約カレンダー画面 ----------
async function renderCalendar() {
  roomsCache = await api.rooms();
  const days = [...Array(7)].map((_, i) => addDays(weekStart, i));
  const dateFrom = fmtDate(days[0]);
  const dateTo = fmtDate(days[6]);
  const roomFilter = document.getElementById("room-filter")?.value || "";
  const reservations = await api.reservations(dateFrom, dateTo, roomFilter || undefined);
  const rooms = roomFilter ? roomsCache.filter((r) => String(r.id) === roomFilter) : roomsCache;

  const byRoomDate = {};
  for (const r of reservations) {
    const key = `${r.room_id}_${r.date}`;
    (byRoomDate[key] = byRoomDate[key] || []).push(r);
  }

  const header = days.map((d) => `<th>${fmtDate(d)}</th>`).join("");
  const rows = rooms
    .map((room) => {
      const cells = days
        .map((d) => {
          const key = `${room.id}_${fmtDate(d)}`;
          const dayReservations = byRoomDate[key] || [];
          if (dayReservations.length === 0) {
            return `<td class="cell-empty" onclick="prefillReservation(${room.id}, '${fmtDate(d)}')">(空き)</td>`;
          }
          return `<td>${dayReservations
            .map(
              (r) =>
                `<div class="cell-booked" onclick="navigate('#/reservations/${r.id}')">${r.start_time}-${r.end_time} ${escapeHtml(r.subject)} (${escapeHtml(r.created_by_name)})</div>`
            )
            .join("")}</td>`;
        })
        .join("");
      return `<tr><th>${escapeHtml(room.name)}</th>${cells}</tr>`;
    })
    .join("");

  appEl.innerHTML = `
    <h2>予約カレンダー</h2>
    <div>
      <button id="prev-week">&laquo; 前週</button>
      <button id="next-week">次週 &raquo;</button>
      会議室フィルタ:
      <select id="room-filter">
        <option value="">(全会議室)</option>
        ${roomsCache.map((r) => `<option value="${r.id}" ${String(r.id) === roomFilter ? "selected" : ""}>${escapeHtml(r.name)}</option>`).join("")}
      </select>
    </div>
    <table><thead><tr><th>会議室</th>${header}</tr></thead><tbody>${rows}</tbody></table>
    <p class="hint">空きセルをクリックすると予約作成画面に移動します。予約済みセルをクリックすると詳細画面に移動します。</p>
  `;
  document.getElementById("prev-week").onclick = () => {
    weekStart = addDays(weekStart, -7);
    renderCalendar();
  };
  document.getElementById("next-week").onclick = () => {
    weekStart = addDays(weekStart, 7);
    renderCalendar();
  };
  document.getElementById("room-filter").onchange = () => renderCalendar();
}

window.prefillReservation = (roomId, date) => {
  sessionStorage.setItem("prefill_room_id", roomId);
  sessionStorage.setItem("prefill_date", date);
  navigate("#/reservations/new");
};

// ---------- S03 予約作成画面 ----------
async function renderReservationForm() {
  roomsCache = await api.rooms();
  const prefillRoom = sessionStorage.getItem("prefill_room_id") || "";
  const prefillDate = sessionStorage.getItem("prefill_date") || "";
  sessionStorage.removeItem("prefill_room_id");
  sessionStorage.removeItem("prefill_date");

  appEl.innerHTML = `
    <h2>予約作成</h2>
    <form id="reservation-form">
      <label>会議室
        <select name="room_id" required>
          ${roomsCache.map((r) => `<option value="${r.id}" ${String(r.id) === prefillRoom ? "selected" : ""}>${escapeHtml(r.name)}</option>`).join("")}
        </select>
      </label>
      <label>日付<input type="date" name="date" required value="${prefillDate}"></label>
      <label>開始時刻<input type="time" name="start_time" required value="10:00"></label>
      <label>終了時刻<input type="time" name="end_time" required value="11:00"></label>
      <label>件名<input type="text" name="subject" required maxlength="100"></label>
      <label>備考<textarea name="notes" maxlength="500"></textarea></label>
      <div class="error" id="form-error"></div>
      <button type="submit">登録</button>
      <button type="button" id="cancel-btn">キャンセル</button>
    </form>
  `;
  document.getElementById("cancel-btn").onclick = () => navigate("#/calendar");
  document.getElementById("reservation-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = {
      room_id: Number(fd.get("room_id")),
      date: fd.get("date"),
      start_time: fd.get("start_time"),
      end_time: fd.get("end_time"),
      subject: fd.get("subject"),
      notes: fd.get("notes") || "",
      participant_ids: [],
    };
    try {
      await api.createReservation(payload);
      navigate("#/calendar");
    } catch (err) {
      document.getElementById("form-error").textContent = err.message;
    }
  };
}

// ---------- S04 予約詳細・編集画面 ----------
async function renderReservationDetail(id) {
  const r = await api.reservation(id);
  const canEdit = currentUser.role === "admin" || currentUser.id === r.created_by;
  appEl.innerHTML = `
    <h2>予約詳細</h2>
    <form id="detail-form">
      <label>会議室: ${escapeHtml(r.room_name)}</label>
      <label>日付<input type="date" name="date" value="${r.date}" ${canEdit ? "" : "disabled"}></label>
      <label>開始時刻<input type="time" name="start_time" value="${r.start_time}" ${canEdit ? "" : "disabled"}></label>
      <label>終了時刻<input type="time" name="end_time" value="${r.end_time}" ${canEdit ? "" : "disabled"}></label>
      <label>件名<input type="text" name="subject" value="${escapeHtml(r.subject)}" maxlength="100" ${canEdit ? "" : "disabled"}></label>
      <label>備考<textarea name="notes" maxlength="500" ${canEdit ? "" : "disabled"}>${escapeHtml(r.notes || "")}</textarea></label>
      <label>予約者: ${escapeHtml(r.created_by_name)}</label>
      <div class="error" id="detail-error"></div>
      ${canEdit ? '<button type="submit">更新</button><button type="button" id="cancel-reservation-btn">取消</button>' : "<p class=\"hint\">この予約は編集できません(予約者本人または管理者のみ編集可)。</p>"}
      <button type="button" id="back-btn">戻る</button>
    </form>
  `;
  document.getElementById("back-btn").onclick = () => navigate("#/calendar");
  if (canEdit) {
    document.getElementById("cancel-reservation-btn").onclick = async () => {
      await api.deleteReservation(id);
      navigate("#/calendar");
    };
    document.getElementById("detail-form").onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const payload = {
        room_id: r.room_id,
        date: fd.get("date"),
        start_time: fd.get("start_time"),
        end_time: fd.get("end_time"),
        subject: fd.get("subject"),
        notes: fd.get("notes") || "",
        participant_ids: r.participant_ids || [],
      };
      try {
        await api.updateReservation(id, payload);
        navigate("#/calendar");
      } catch (err) {
        document.getElementById("detail-error").textContent = err.message;
      }
    };
  }
}

// ---------- S05 マイ予約一覧画面 ----------
async function renderMyReservations() {
  const period = document.getElementById("period-filter")?.value || "future";
  const list = await api.myReservations(period);
  appEl.innerHTML = `
    <h2>マイ予約一覧</h2>
    <label>期間
      <select id="period-filter">
        <option value="future" ${period === "future" ? "selected" : ""}>今後の予約</option>
        <option value="past" ${period === "past" ? "selected" : ""}>過去の予約</option>
      </select>
    </label>
    <table><thead><tr><th>日付</th><th>会議室</th><th>時間帯</th><th>件名</th></tr></thead>
    <tbody>
      ${list
        .map(
          (r) =>
            `<tr onclick="navigate('#/reservations/${r.id}')" style="cursor:pointer">
              <td>${r.date}</td><td>${escapeHtml(r.room_name)}</td><td>${r.start_time}-${r.end_time}</td><td>${escapeHtml(r.subject)}</td>
            </tr>`
        )
        .join("")}
    </tbody></table>
  `;
  document.getElementById("period-filter").onchange = () => renderMyReservations();
}

// ---------- S06 会議室管理画面 ----------
async function renderRoomsAdmin() {
  const rooms = await api.rooms();
  appEl.innerHTML = `
    <h2>会議室管理</h2>
    <table><thead><tr><th>会議室名</th><th>収容人数</th><th>設備</th><th>状態</th><th></th></tr></thead>
    <tbody>
      ${rooms
        .map(
          (r) => `<tr>
            <td>${escapeHtml(r.name)}</td><td>${r.capacity}</td><td>${escapeHtml(r.equipment || "")}</td>
            <td>${r.is_active ? "有効" : "無効"}</td>
            <td><button onclick="deleteRoomAction(${r.id})">削除</button></td>
          </tr>`
        )
        .join("")}
    </tbody></table>
    <h3>新規登録</h3>
    <form id="room-form">
      <label>会議室名<input type="text" name="name" required maxlength="50"></label>
      <label>収容人数<input type="number" name="capacity" required min="1"></label>
      <label>設備<input type="text" name="equipment" maxlength="200" placeholder="例: プロジェクタ,ホワイトボード"></label>
      <div class="error" id="room-error"></div>
      <button type="submit">登録</button>
    </form>
  `;
  document.getElementById("room-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api.createRoom({
        name: fd.get("name"),
        capacity: Number(fd.get("capacity")),
        equipment: fd.get("equipment") || "",
      });
      renderRoomsAdmin();
    } catch (err) {
      document.getElementById("room-error").textContent = err.message;
    }
  };
}
window.deleteRoomAction = async (id) => {
  await api.deleteRoom(id);
  renderRoomsAdmin();
};

// ---------- S07 ユーザー管理画面 ----------
async function renderUsersAdmin() {
  const users = await api.users();
  appEl.innerHTML = `
    <h2>ユーザー管理</h2>
    <table><thead><tr><th>社員ID</th><th>氏名</th><th>権限</th><th>状態</th><th></th></tr></thead>
    <tbody>
      ${users
        .map(
          (u) => `<tr>
            <td>${escapeHtml(u.employee_id)}</td><td>${escapeHtml(u.name)}</td><td>${u.role === "admin" ? "管理者" : "一般"}</td>
            <td>${u.is_active ? "有効" : "無効"}</td>
            <td><button onclick="deleteUserAction(${u.id})">削除</button></td>
          </tr>`
        )
        .join("")}
    </tbody></table>
    <h3>新規登録</h3>
    <form id="user-form">
      <label>社員ID<input type="text" name="employee_id" required maxlength="20"></label>
      <label>氏名<input type="text" name="name" required maxlength="50"></label>
      <label>権限
        <select name="role"><option value="general">一般</option><option value="admin">管理者</option></select>
      </label>
      <label>初期パスワード<input type="password" name="password" required minlength="8"></label>
      <div class="error" id="user-error"></div>
      <button type="submit">登録</button>
    </form>
  `;
  document.getElementById("user-form").onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api.createUser({
        employee_id: fd.get("employee_id"),
        name: fd.get("name"),
        role: fd.get("role"),
        password: fd.get("password"),
      });
      renderUsersAdmin();
    } catch (err) {
      document.getElementById("user-error").textContent = err.message;
    }
  };
}
window.deleteUserAction = async (id) => {
  await api.deleteUser(id);
  renderUsersAdmin();
};

window.addEventListener("hashchange", router);
window.addEventListener("DOMContentLoaded", router);
