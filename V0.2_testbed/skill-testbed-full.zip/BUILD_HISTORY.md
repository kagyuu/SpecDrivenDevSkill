# Build History

| Build ID | Version | Date/Time | Commit | Build Command | Test Command | Result | Notes |
|---|---|---|---|---|---|---|---|
| B001 | 0.1.0 | 2026-07-30 (Phase 6) | 14fe965 | `cd server && python3 -c "from app.main import create_app; create_app(':memory:')"` | `cd server && python3 -m unittest discover -s tests -p "test_*.py"` | PASS (46/46) | 初回実装。uv/pyproject.tomlは用意したが`uv sync`はネットワーク遮断のため未実行。 |
| B002 | 0.1.0 | 2026-07-30 (Phase 7) | 11599de | 同上 | 同上(+ `tests/system`) | FAIL (54/55, T004の1件がFAIL) | 参加者ID実在チェック不足によるFK違反(500)を検出。 |
| B003 | 0.1.0 | 2026-07-30 (Phase 8) | 4d529bc | 同上 | 同上 | PASS (55/55) | F001修正後の再テストで全件PASS。 |
| B004 | 0.1.0 | 2026-07-30 (Phase 9) | 未取得(本コミット作成前のため) | 同上 | 同上 | PASS (55/55) | 納品物取りまとめ。Docker Composeでの起動確認は未実施(下記10章参照)。 |
