# プログラム実装定義(目次) — 会議室予約システム

> 本書は `spec-driven-dev` Skill フェーズ6の成果物です。OKF形式(`SKILL.md`参照)の目次です。
> インプット: `docs/02-frontend-spec.md`, `docs/03-backend-spec.md`, `docs/04-impl-plan.md`, `docs/05-test-plan.md`

## コード格納先

* クライアント・サーバ型のため `server/`(Python, uv)、`client/`(静的フロントエンド)を用いる。
* **仕様からの逸脱(要記録)**: `docs/01-requirement.md` はフロントエンドに React 18 + TypeScript + Vite を指定しているが、本検証環境はネットワーク分離されており `npm install` によるパッケージ取得(react/vite等のレジストリ取得)が一切できない(`registry.npmjs.org` への到達が403で拒否される)。そのため `client/` は依存パッケージ不要の素のHTML/CSS/JavaScript(ES Modules、ビルド不要)で実装する。バックエンドは `FastAPI` 自体もPyPIから取得できないため、FastAPIの内部基盤である `Starlette` + `Pydantic`(いずれも事前インストール済み)を直接用いて同等のASGI REST APIを実装する。これは `docs/01-requirement.md` の技術選定からの意図的な逸脱であり、`e2e-validation-report.md` に理由とともに記録する。SKILL自体の欠陥ではなく実行環境起因の制約である。

## スプリント一覧(OKF形式)

- [x] U001 [foundation: DBスキーマ・認証基盤・ログイン画面](./06-impl-direction/U001-foundation.md) — sessions/users/rooms/reservations等のスキーマ、ログイン/ログアウト/me API、S01画面
- [x] U002 [rooms-and-calendar-read: 会議室CRUD・予約参照系・カレンダー系画面](./06-impl-direction/U002-rooms-and-calendar-read.md) — 会議室CRUD API、予約参照API、S02/S05/S06画面
- [x] U003 [reservation-write: 予約作成・変更・取消(重複チェック)](./06-impl-direction/U003-reservation-write.md) — 予約作成/更新/取消API、S03/S04画面
- [x] U004 [user-admin-and-hardening: ユーザー管理・横断機能仕上げ](./06-impl-direction/U004-user-admin-and-hardening.md) — ユーザーCRUD API、S07画面、エラーハンドリング/認可の仕上げ

## 実施結果サマリ

* 全4スプリントの実装・Unit Test・スプリント内結合テストを完了した(2026-07-30実施)。
* Unit Test: 42件 PASS / 0 FAIL(`server/tests/test_*.py`、`python3 -m unittest discover -s tests -p "test_*.py"`)。
* スプリント内結合テスト(結合確認用の薄いタスク): 4件 PASS / 0 FAIL(`server/tests/integration/test_u00{1,2,3,4}_*.py`、実サーバー(uvicorn)をサブプロセス起動しHTTPで検証)。
* `uv sync` によるビルドは、本検証環境がPyPIへのネットワークアクセスを持たないため実行できなかった(`docs/03-backend-spec.md`は変更していない。事前インストール済みのシステムPythonパッケージ(starlette/uvicorn/pydantic)で動作確認済み)。この制約は`e2e-validation-report.md`に記録する。

## 未解決事項

* なし(`docs/02-frontend-spec.md` / `docs/03-backend-spec.md` に対する不足・矛盾は発見されなかった)。
