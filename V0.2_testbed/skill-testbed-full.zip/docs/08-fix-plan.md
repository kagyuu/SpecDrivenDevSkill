# 修正計画書(目次) — 会議室予約システム

> 本書は `spec-driven-dev` Skill フェーズ8の成果物です。OKF形式(`SKILL.md`参照)の目次です。
> インプット: `docs/07-test-direction.md`、`docs/test-records/20260730-1500-test-record.md`(最新)

## 概要

`docs/test-records/20260730-1500-test-record.md` の T004 で1件のテスト失敗を検出した。該当failに対応する修正指示を1件作成する。

## 修正タスク一覧(OKF形式)

- [x] F001 [予約作成時の存在しない参加者IDによる500エラー](./08-fix-plan/fixed/F001-invalid-participant-id-500.md) — T004で検出。参加者ID実在チェックを追加し400に修正済み(解決済み)。

修正完了に伴い、`docs/08-fix-plan/F001-invalid-participant-id-500.md`(未対応版)は削除し、`docs/08-fix-plan/fixed/F001-invalid-participant-id-500.md` に詳細付きで移動済み。概要は `docs/08-fix-plan/08-fix-resolved.md` を参照。未解決障害はない(`docs/08-fix-plan/08-fix-unresolved.md`参照)。
