# 結合テスト定義(目次) — 会議室予約システム

> 本書は `spec-driven-dev` Skill フェーズ7の成果物です。OKF形式(`SKILL.md`参照)の目次です。
> インプット: `docs/02-frontend-spec.md`, `docs/03-backend-spec.md`, `docs/04-impl-plan.md`, `docs/05-test-plan.md`

## ビルド手順(テスト前提)

* ビルド対象: `server/`(Python, Starlette/Pydantic — `docs/06-impl-direction.md`記載のFastAPI代替方針を継続)
* ビルドコマンド: 本検証環境はネットワーク分離のため `uv sync` は実行不可。事前インストール済みシステムパッケージ(`starlette`, `uvicorn`, `pydantic`)を用い、`cd server && python3 -c "from app.main import create_app; create_app(':memory:')"` でモジュールが正常にimport・初期化できることをビルド成功の代替確認とする。
* 成功条件: 上記コマンドが例外なく終了すること。
* 失敗時の記録方法: `docs/test-records/*.md` の該当タスクに「事前ビルド結果: FAIL」として記録し、以降のテストを `NOT RUN` とする。
* ビルド失敗時はテストへ進まない。

## テストタスク一覧(OKF形式)

- [x] T001 [フルユーザージャーニー(スプリント横断)](./07-test-direction/T001-full-user-journey.md) — ログイン→会議室登録→予約作成→カレンダー反映→編集→取消
- [x] T002 [権限をまたぐアクセス制御確認](./07-test-direction/T002-cross-cutting-authorization.md) — 一般ユーザーによる管理者専用API/画面へのアクセス拒否
- [x] T003 [同時実行時の排他制御(二重予約防止)](./07-test-direction/T003-concurrent-booking.md) — 同一会議室・同一時間帯への同時リクエストで二重予約が発生しないこと
- [x] T004 [エラーハンドリング一連の確認](./07-test-direction/T004-error-handling.md) — 不正なリクエストボディ・存在しないリソースへのアクセス時の挙動確認(**FAIL** → フェーズ8へ引き渡し済み、修正後再テストでPASS。詳細は`docs/test-records/`および`docs/08-fix-plan/08-fix-resolved.md`参照)
- [x] T005 [性能観点: カレンダー表示APIの応答時間](./07-test-direction/T005-performance-calendar.md) — ローカル計測での目安確認(参考値)

## フェーズ8への引き渡し状況

T004 で1件のFAILが検出され、フェーズ8(`docs/08-fix-plan.md`)で修正済み(F001)。修正後の再テスト結果は `docs/test-records/20260730-1530-test-record.md` に追記し、本目次のT004チェックボックスは再テストPASSを確認した上で `[x]` としている(結果はFAIL→修正→PASSの経緯を含めてテスト記録に残っている)。
