# 会議室予約システム

`spec-driven-dev` Skill(V0.2)のフェーズ2〜9を用いて実装した、社内会議室予約Webアプリケーション。
仕様の全体は `docs/01-requirement.md` 以下の各設計書、検証結果は `e2e-validation-report.md` を参照。

## 技術スタック(実装時の逸脱を含む)

* バックエンド: Python 3.11 + Starlette/Pydantic(仕様上はFastAPIだが、本検証環境がオフラインでFastAPI自体を取得できないため、その基盤であるStarlette+Pydanticで同等のREST APIを実装した。詳細は `docs/06-impl-direction.md` および `e2e-validation-report.md` 参照)
* フロントエンド: ビルド不要の素のHTML/CSS/JavaScript(仕様上はReact 18 + TypeScript + Viteだが、同様の理由でnpmパッケージ取得ができないための代替)
* データストア: SQLite(`server/data/app.db`、実行時に自動作成・初期データ投入)

## ローカルでの起動方法(Docker未使用)

```bash
cd server
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

ブラウザで `http://localhost:8000/` を開くとログイン画面が表示される。

デモ用アカウント:

| 社員ID | パスワード | 権限 |
|---|---|---|
| admin | admin12345 | 管理者 |
| u001 | password01 | 一般 |
| u002 | password02 | 一般 |

## Docker Composeでの起動方法(未実地検証、手順のみ)

```bash
cp .env.example .env
docker compose build
docker compose up -d
curl http://localhost:8000/health
```

本検証環境はネットワーク分離のためベースイメージ取得ができず、上記コマンドの実地検証は行っていない。`docs/09-deliver.md` 10章を参照。

## テストの実行方法

```bash
cd server
python3 -m unittest discover -s tests -p "test_*.py"
```

Unit Test 42件、スプリント内結合テスト4件、システムテスト(T001〜T005)9件、計55件が全てPASSする(2026-07-30時点)。
